class FactorialJS {

    constructor() {
        this.form = document.getElementById('formFactorial');
        this.mensaje = document.getElementById('mensaje');

        this.form.addEventListener("submit", (e) => {
            e.preventDefault();
            this.calcular();
        });
    }

    calcular() {
        const n = parseInt(document.getElementById("numero").value);

        let resultado = 1;
        let pasos = [];

        for (let i = 1; i <= n; i++) {
            resultado *= i;
            pasos.push(i);
        }

        const procedimiento = `${n}! = ${pasos.join(" × ")} = ${resultado}`;
        const esPar = resultado % 2 === 0;

        this.mensaje.innerHTML = `
            ${procedimiento} <br>
            Resultado final: 
            <span class="${esPar ? 'success' : 'error'}">${resultado}</span>
        `;
    }
}

document.addEventListener("DOMContentLoaded", () => new FactorialJS());
