<?php

class LoginPHP {

    private $usuarioValido;
    private $passwordValido;

    public function __construct()
    {
        
        $this->usuarioValido = "admin";
        $this->passwordValido = "12345";

        
    }

    public function procesarSolicitud()
    {
        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            return $this->respuesta("Acceso no permitido.");
        }

        $usuario = trim($_POST["usuario"] ?? "");
        $password = trim($_POST["password"] ?? "");

        if ($usuario === "" || $password === "") {
            return $this->respuesta("Complete todos los campos.");
        }

        return $this->validar($usuario, $password);
    }

    private function validar($usuario, $password)
    {
        if ($usuario === $this->usuarioValido && $password === $this->passwordValido) {
            return $this->respuesta("OK");
        } else {
            return $this->respuesta("Usuario o contraseña incorrectos.");
        }
    }

    private function respuesta($mensaje)
    {
        echo $mensaje;
    }
}

$login = new LoginPHP();
$login->procesarSolicitud();

?>
