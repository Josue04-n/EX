class Login {

    constructor() {
        this.usuario = document.getElementById('usuario');
        this.password = document.getElementById('password');
        this.formulario = document.getElementById('formularioLogin');
        this.mensaje = document.getElementById('mensaje');

        this.eventos();
    }

    eventos() {
        this.formulario.addEventListener("submit", (e) => {
            e.preventDefault();
            this.enviar();
        });
    }

    async enviar() {
        const datos = new FormData(this.formulario);

        try {
            const respuesta = await fetch("index.php", {
                method: "POST",
                body: datos
            });

            const resultado = await respuesta.text();
            this.procesarRespuesta(resultado);

        } catch (error) {
            this.mostrar("Error de conexión con el servidor.", false);
        }
    }

    procesarRespuesta(res) {
        if (res === "OK") {
            this.mostrar("¡Bienvenido!", true);
            this.formulario.reset();
        } else {
            this.mostrar(res, false);
        }
    }

    mostrar(texto, exito) {
        this.mensaje.textContent = texto;
        this.mensaje.className = "mensaje " + (exito ? "success" : "error");
        this.formulario.className = "formulario " + (exito ? "correcto" : "error");
    }
}

document.addEventListener("DOMContentLoaded", () => new Login());
