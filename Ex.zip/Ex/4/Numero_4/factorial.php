<?php

class Factorial {

    private $n;

    public function __construct($n) {
        $this->n = $n;
    }

    public function calcular() {
        $res = 1;
        $pasos = [];

        for ($i = 1; $i <= $this->n; $i++) {
            $res *= $i;
            $pasos[] = $i;
        }

        $procedimiento = $this->n . "! = " . implode(" × ", $pasos) . " = " . $res;

        return json_encode([
            "procedimiento" => $procedimiento,
            "resultado" => $res
        ]);
    }
}

$n = $_POST["numero"];
$fact = new Factorial($n);
echo $fact->calcular();
?>
