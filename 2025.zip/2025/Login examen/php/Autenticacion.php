<?php
class Autenticacion {

    private $usuario;
    private $password;

    public function __construct() {
        $this->usuario = "admin";
        $this->password = "admin123";
    }

    public function login($usuarioIngresado, $passwordIngresado) {
        $usuarioIngresado = trim($usuarioIngresado);
        $passwordIngresado = trim($passwordIngresado);

        if ($usuarioIngresado == '' || $passwordIngresado == '') {
            return [
                'ok' => false,
                'message' => 'Complete todos los campos.'
            ];
        }

        if ($usuarioIngresado == $this->usuario && $passwordIngresado == $this->password) {
            return [
                'ok' => true,
                'message' => 'Bienvenido ' . htmlspecialchars_decode($this->usuario)
            ];

        } else {
            return [
                'ok' => false,
                'message' => 'Usuario o contraseña incorrectos. Inténtelo de nuevo.'
            ];
        }
    }
}
