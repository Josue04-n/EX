<?php
require_once 'Autenticacion.php';

$usuario = '';
$mensaje = '';
$tipoMensaje = '';
$estadoLogin = ''; 

    
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'] ?? '';
    $password = $_POST['password'] ?? '';

    $autenticacion = new Autenticacion();
    $resultado = $autenticacion->login($usuario, $password);

    $mensaje = $resultado['message']; 
    $estadoLogin = $resultado['ok'] ? 'correcto' : 'error';
    $tipoMensaje = $resultado['ok'] ? 'success' : 'error';
    
}


?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login simple</title>
<link rel="stylesheet" href="../css/style.css">
</head>

<body>
<form action="" method="post" class="formulario <?php echo $estadoLogin; ?>">
    <h2>INICIAR SESIÓN</h2>
    <label>Usuario</label>
    <input type="text" name="usuario" placeholder="Usuario">
    <label>Contraseña</label>
    <input type="password" name="password" placeholder="Contraseña">
    <input type="submit" value="Entrar">

    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && $mensaje): ?>
        <div class="mensaje <?php echo $tipoMensaje; ?>">
            <?php echo htmlspecialchars($mensaje); ?>
        </div>
    <?php endif; ?>
</form>
    
</body>
</html>
