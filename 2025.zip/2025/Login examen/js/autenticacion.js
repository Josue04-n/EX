// Clase de autenticación en JavaScript
class Autenticacion {
    constructor() {
        this.usuario = "admin";
        this.password = "admin123";
    }

    login(usuarioIngresado, passwordIngresado) {
        // Trimear espacios en blanco
        usuarioIngresado = usuarioIngresado.trim();
        passwordIngresado = passwordIngresado.trim();

        // Validar que los campos no estén vacíos
        if (usuarioIngresado === '' || passwordIngresado === '') {
            return {
                ok: false,
                message: 'Complete todos los campos.'
            };
        }

        // Validar credenciales
        if (usuarioIngresado === this.usuario && passwordIngresado === this.password) {
            return {
                ok: true,
                message: 'Bienvenido ' + this.usuario
            };
        } else {
            return {
                ok: false,
                message: 'Usuario o contraseña incorrectos. Inténtelo de nuevo.'
            };
        }
    }
}

// Lógica del formulario de login en JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const formulario = document.querySelector('.formulario');
    const inputUsuario = document.querySelector('input[name="usuario"]');
    const inputPassword = document.querySelector('input[name="password"]');

    formulario.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevenir envío del formulario

        const usuario = inputUsuario.value;
        const password = inputPassword.value;

        // Crear instancia de autenticación
        const autenticacion = new Autenticacion();
        const resultado = autenticacion.login(usuario, password);

        // Limpiar mensajes anteriores
        const mensajeAnterior = document.querySelector('.mensaje');
        if (mensajeAnterior) {
            mensajeAnterior.remove();
        }

        // Actualizar clase del formulario
        formulario.classList.remove('correcto', 'error');
        if (resultado.ok) {
            formulario.classList.add('correcto');
        } else {
            formulario.classList.add('error');
        }

        // Crear y mostrar mensaje
        const div = document.createElement('div');
        div.classList.add('mensaje', resultado.ok ? 'success' : 'error');
        div.textContent = resultado.message;
        formulario.appendChild(div);

        
    });
});

