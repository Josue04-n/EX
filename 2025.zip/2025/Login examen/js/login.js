// Lógica del formulario de login en JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const formulario = document.querySelector('.formulario');
    const inputUsuario = document.querySelector('input[name="usuario"]');
    const inputPassword = document.querySelector('input[name="password"]');

    formulario.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevenir envío del formulario

        const usuario = inputUsuario.value;
        const password = inputPassword.value;

        // Crear instancia de autenticación
        const autenticacion = new Autenticacion();
        const resultado = autenticacion.login(usuario, password);

        // Limpiar mensajes anteriores
        const mensajeAnterior = document.querySelector('.mensaje');
        if (mensajeAnterior) {
            mensajeAnterior.remove();
        }

        // Actualizar clase del formulario
        formulario.classList.remove('correcto', 'error');
        if (resultado.ok) {
            formulario.classList.add('correcto');
        } else {
            formulario.classList.add('error');
        }

        // Crear y mostrar mensaje
        const div = document.createElement('div');
        div.classList.add('mensaje', resultado.ok ? 'success' : 'error');
        div.textContent = resultado.message;
        formulario.appendChild(div);
    });
});
