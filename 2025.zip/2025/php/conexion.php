<?php
class Conexion{
private $usuario;
private $contraseña;

public function __construct($usuario, $contraseña) {
  $this->usuario = $usuario;
  $this->contraseña = $contraseña;
}

public function conectar(){

  $user = "Juan";
  $pass = "123";
  $resultado = ["mensaje" =>"","tipo"=>"alerta"];


  if($this->usuario === "" || $this->contraseña ===""){
    $resultado["mensaje"] ="Ingrese sus credenciales";
    $resultado["tipo"] = "alerta";
  }else if($this->usuario === $user && $this->contraseña === $pass){
     $resultado["mensaje"] ="Bienvenido";
    $resultado["tipo"] = "exito";
  }else{
     $resultado["mensaje"] ="Crendeciales incorrectas";
    $resultado["tipo"] = "error";
  }
  return $resultado;
}

}
?>