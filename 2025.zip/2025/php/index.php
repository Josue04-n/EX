<?php

include_once "conexion.php";

$mensaje = "";
$clase_mensaje = "";

if($_SERVER['REQUEST_METHOD']==='POST'){
$usuario = $_POST['usuario'];
$contraseña = $_POST['contraseña'];

$con = new Conexion($usuario, $contraseña);

$resultado = $con->conectar();
$mensaje = $resultado['mensaje'];
$clase_mensaje = $resultado['tipo'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <label>Usuario</label>
        <input type="text" name="usuario" id="usuario" class="<?=$clase_mensaje?>">
        <label>Contraseña</label>
        <input type="password" name="contraseña" id="contraseña" class="<?=$clase_mensaje?>">
        <button>Ingresar</button>
        <div id="mensaje"class="<?=$clase_mensaje?>"><?=$mensaje?></div>

        <script>
            setTimeout(()=>{
                document.getElementById("mensaje").textContent="";
            },3000);
        </script>

    </form>
</body>
</html>