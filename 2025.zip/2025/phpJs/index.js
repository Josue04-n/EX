class datos{

    constructor(){
        this.inputUsuario = document.getElementById("usuario");
        this.inputContraseña = document.getElementById("contraseña");
        this.mensaje = document.getElementById("mensaje");
        this.btnIngresar = document.getElementById("ingresar");
        this.iniciar();
    }


    iniciar(){
        this.btnIngresar.addEventListener("click",(event)=>{
            event.preventDefault();
            this.enviarDatos();
        });
    }

    enviarDatos(){

        const formDta = new FormData();
        formDta.append('usuario', this.inputUsuario.value);
        formDta.append('contraseña', this.inputContraseña.value);

        fetch('index.php',
            {
                method: 'POST',
                body: formDta
            }
        )
        .then(response=> response.json())
        .then(data =>{
            console.log('Respuesta: ',data);
            this.mensaje.textContent= data.mensaje;
            this.mensaje.className= data.tipo;
        })
        .catch(error=> {
            console.error('Error: ',error)
            this.mensaje.textContent='Error de conexion';
            this.mensaje.className= "error";
        });
    }
}

dt = new datos();