<?php
include_once "conexion.php";

if($_SERVER['REQUEST_METHOD']==='POST'){
    $usuario = $_POST['usuario']?? '';
    $contraseña = $_POST['contraseña']?? '';

    $conectar = new conectar($usuario, $contraseña);
    $respuesta = $conectar->validar();

    header('Content-Type: application/json');
    echo json_encode($respuesta);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .exito { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .alerta { color: orange; font-weight: bold; }
    </style>
</head>
<body>
    <form>
        <input type="text" id="usuario" name="usuario" placeholder="Usuario">
        <input type="password" id="contraseña" name="contraseña" placeholder="Contraseña">
        <button type="button" id="ingresar">Ingresar</button>
        <div id="mensaje"></div>
    </form>

   <script src="index.js"></script>
</body>
</html>