<?php


class conectar{
 
    private $usuario;
    private $contraseña;
public function __construct($usuario,$contraseña) {
    $this->usuario= $usuario;
    $this->contraseña = $contraseña;

}

function validar(){
    $user = "juan";
    $cont = "123";
    $respuesta = ["mensaje"=>"", "tipo"=>"alerta"];
    

    if($this->usuario === "" || $this->contraseña ==""){
        $respuesta ["mensaje"]="Ingrese sus datos"; 
        $respuesta["tipo"]="alerta";
        return $respuesta;
    }else if($this->usuario === $user && $this->contraseña == $cont){
        $respuesta ["mensaje"]="Bienvenido"; 
        $respuesta["tipo"]="exito";
        return $respuesta;
    }else{
        $respuesta ["mensaje"]="Credenciales incorrectas"; 
        $respuesta["tipo"]="error";
        return $respuesta;
    }
}
}


?>