class formulario{

    constructor(){
        this.usuario = document.getElementById("usuario");
        this.contraseña = document.getElementById("contraseña");
        this.acceso = document.getElementById("acceso");
        this.ingresar = document.getElementById("ingresar");
        this.iniciar();
    }

    validacion(){

        let user = "juan";
        let pass = "123";

        if(this.usuario.value === "" || this.contraseña.value === ""){
             this.acceso.textContent = "Ingrese sus credenciales";
        }
        else if(this.usuario.value === user && this.contraseña.value === pass){
            this.acceso.className = "correcto";
            this.acceso.textContent = "Bienvenido";
        }else{
            this.acceso.className = "incorrecto";
            this.acceso.textContent = "Credenciales incorrectas";
            return;
        }
    }

    iniciar(){
        this.ingresar.addEventListener("click",()=>{
            event.preventDefault();
            this.validacion();
        });
    }
}

formulario = new formulario();