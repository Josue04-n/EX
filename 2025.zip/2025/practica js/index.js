  
class inicio{

    constructor(password, usuario){
        this.password = password;
        this.usuario = usuario;
    }

     ingresar() {
        let user = "juan";
        let pass = "juan123";

        if(this.usuario ===  user  && this.password === pass){
            return true;
        }else{
            return false;
        }
    }
}
document.getElementById("ingresar").addEventListener("click", function(){
    event.preventDefault();
let user = document.getElementById("usuario");
let pass = document.getElementById("password");
let validar = document.getElementById("validar");

let usuario = user.value;
let password = pass.value;

conectar = new inicio(password,usuario);
conectar.ingresar();

if (conectar.ingresar()){
user.className = "correcto";
pass.className = "correcto";
validar.className = "correcto";    
validar.innerText = "Bienvenido";
}else{
user.className = "incorrecto";
pass.className = "incorrecto";
validar.className = "incorrecto";    
validar.innerText = "Credenciales Incorrectas";
}
});