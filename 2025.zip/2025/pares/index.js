class numerosPares{

    constructor(){
        this.numero = document.getElementById("numero");
        this.ingresar = document.getElementById("ingresar");
        this.sumar = document.getElementById("sumar");
        this.total = document.getElementById("resultado");

        this.numerosGuardados=[];
        this.iniciar();
    }


    convertir(){
        let numero = parseFloat(this.numero.value);
        return numero;
    }

    ingresarNumeros(){
        
        this.total.textContent = "";
       const num = this.convertir();
       if(num %2==0){
       this.numerosGuardados.push(num);
       this.numero.value="";
       }else{
        this.total.textContent="Ingrese Numero Pares";
        this.total.value = "";
       }

    }

    sumarNumeros(){
        this.total.textContent = "";
        let sumaTotal = 0;
        for(let i=0; i< this.numerosGuardados.length; i++){
            sumaTotal +=this.numerosGuardados[i];
        }
        this.total.textContent = "La suma total es: "+ sumaTotal;
        this.total.value = "";
    }

    iniciar(){
        this.ingresar.addEventListener("click", () =>{
            this.ingresarNumeros();
        });
        
        this.sumar.addEventListener("click", () =>{
            this.sumarNumeros();
        });
    }
}

suma = new numerosPares();