class FactorialJS {

    constructor() {
        this.formulario = document.getElementById('formFactorial');
        this.mensaje = document.getElementById('mensaje');

        this.formulario.addEventListener("submit", (e) => {
            e.preventDefault();
            this.enviar();
        });
    }

    async enviar() {
        const datos = new FormData(this.formulario);

        const respuesta = await fetch("factorial.php", {
            method: "POST",
            body: datos
        });

        const res = await respuesta.text();
        const data = JSON.parse(res);

        const resultado = data.resultado;
        const procedimiento = data.procedimiento;
        const esPar = resultado % 2 === 0;

        this.mensaje.innerHTML = `
            ${procedimiento}<br>
            <span class="${esPar ? 'success' : 'error'}">${resultado}</span>
        `;
    }
}

document.addEventListener("DOMContentLoaded", () => new FactorialJS());
