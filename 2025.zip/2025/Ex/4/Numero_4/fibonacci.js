class FibonacciJS {

    constructor() {
        this.form = document.getElementById('formFibonacci');
        this.mensaje = document.getElementById('mensaje');

        this.form.addEventListener("submit", (e) => {
            e.preventDefault();
            this.enviar();
        });
    }

    async enviar() {

        const datos = new FormData(this.form);

        const respuesta = await fetch("fibonacci.php", {
            method: "POST",
            body: datos
        });

        const res = await respuesta.text();
        const data = JSON.parse(res);

        const lista = data.lista.join(" , ");
        const ultimo = data.ultimo;

        const esPar = ultimo % 2 === 0;

        this.mensaje.innerHTML = `
            Secuencia: ${lista}<br>
            Último número: 
            <span class="${esPar ? 'success' : 'error'}">${ultimo}</span>
        `;
    }
}

document.addEventListener("DOMContentLoaded", () => new FibonacciJS());
