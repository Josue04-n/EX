<?php

class Fibonacci {

    private $n;

    public function __construct($n) {
        $this->n = $n;
    }

    public function calcular() {

        $a = 0;
        $b = 1;
        $lista = [];

        for ($i = 0; $i < $this->n; $i++) {
            $lista[] = $a;
            $temp = $a + $b;
            $a = $b;
            $b = $temp;
        }

        return json_encode([
            "lista" => $lista,
            "ultimo" => end($lista)
        ]);
    }
}

$n = $_POST["numero"];
$fib = new Fibonacci($n);
echo $fib->calcular();
?>
