class FibonacciJS {

    constructor() {
        this.form = document.getElementById('formFibonacci');
        this.mensaje = document.getElementById('mensaje');

        this.form.addEventListener("submit", (e) => {
            e.preventDefault();
            this.calcular();
        });
    }

    calcular() {
        const n = parseInt(document.getElementById("numero").value);

        let a = 0;
        let b = 1;
        let lista = [];

        for (let i = 0; i < n; i++) {
            lista.push(a);
            let temp = a + b;
            a = b;
            b = temp;
        }

        const ultimo = lista[lista.length - 1];
        const esPar = ultimo % 2 === 0;

        this.mensaje.innerHTML = `
            Secuencia: ${lista.join(" , ")} <br>
            Último número: 
            <span class="${esPar ? 'success' : 'error'}">${ultimo}</span>
        `;
    }
}

document.addEventListener("DOMContentLoaded", () => new FibonacciJS());
