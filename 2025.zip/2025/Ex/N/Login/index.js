class Login {
    
    constructor() {
        this.usuarioValido = "admin";
        this.passwordValido = "12345";

        this.usuario = document.getElementById('usuario');
        this.password = document.getElementById('password');
        this.boton = document.getElementById('btnEntrar');
        this.mensaje = document.getElementById('mensaje');
        this.formulario = document.getElementById('formularioLogin');

        this.eventos();
    }

    eventos() {
        this.boton.addEventListener("click", () => this.validar());
        this.password.addEventListener("keypress", e => {
            if (e.key === "Enter") this.validar();
        });
    }

    validar() {
        const user = this.usuario.value.trim();
        const pass = this.password.value.trim();

        if (user === "" || pass === "") {
            this.mostrar("Complete todos los campos.", false);
            return;
        }

        if (user === this.usuarioValido && pass === this.passwordValido) {
            this.mostrar(`¡Bienvenido ${user}!`, true);
            this.usuario.value = "";
            this.password.value = "";
        } else {
            this.mostrar("Usuario o contraseña incorrectos.", false);
        }
    }

    mostrar(texto, exito) {
        this.mensaje.textContent = texto;
        this.mensaje.className = "mensaje mostrar " + (exito ? "success" : "error");
        this.formulario.className = "formulario " + (exito ? "correcto" : "error");
    }
}

document.addEventListener("DOMContentLoaded", () => new Login());
