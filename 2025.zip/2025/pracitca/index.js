class factorial {

    constructor() {
        this.numero = document.getElementById("numero");
        this.ingresar = document.getElementById("ingresar");
        this.proceso = document.getElementById("proceso");

        this.iniciar();
    }

    convertir() {
        const num = parseFloat(this.numero.value);
        return num;
    }

    calculoFactorial() {
        const num = this.convertir();

        if (isNaN(num) || num < 0) {
            this.proceso.innerHTML = "Ingresa un número válido";
            return;
        }

        let total = 1;
        let pasos = `<strong>Calculando ${num}!</strong><br><br>`;

        for (let i = 1; i <= num; i++) {
            total = total * i;
            pasos += `Paso ${i}: total = ${total}<br>`;
        }

        pasos += `<br><strong>Resultado final: ${total}</strong>`;

        this.proceso.innerHTML = pasos;
    }

    iniciar() {
        this.ingresar.addEventListener("click", () => {
            this.calculoFactorial();
        });
    }

}

factorial = new factorial();