<?php 
require_once("Models\Model.php");

class EnlacesPaginaController {
    public function plantilla(){
        include "Views/template.php";
    }

    public function enlacesPaginasController(){
        if(isset($_GET["accion"])){
            $enlacesController = $_GET["accion"];
        }
        else{
            $enlacesController ="Inicio.php";
        }
        //$var = new EnlacesPagina();
        //$respuesta = $var -> enlacesPaginasModel($enlacesController);

        //puedo hacerlo estatico y que directamente salga 
        //:: llamado implicito a la clase y accedo a metodos
        $respuesta=EnlacesPagina:: enlacesPaginasModel($enlacesController);
        //mando a la pagina directamente
        include $respuesta;
    }
}
?>