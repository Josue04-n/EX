<?php
// se podia hacer, el queria con el controlador -> require_once "Views/template.php";
require_once "Controllers/controller.php";
$mvc=new EnlacesPaginaController();
$mvc->plantilla();

?>